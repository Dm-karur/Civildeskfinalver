<?php

declare(strict_types=1);

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Libraries\AuthorizationService;
use App\Models\BranchModel;
use CodeIgniter\HTTP\ResponseInterface;
use Throwable;

class BranchesController extends BaseController
{
    private BranchModel $branchModel;
    private AuthorizationService $authorization;

    public function __construct()
    {
        $this->branchModel = new BranchModel();
        $this->authorization = new AuthorizationService();
    }

    /**
     * Return branches accessible to the authenticated user.
     */
    public function index(): ResponseInterface
    {
        $user = auth('session')->user();

        if ($user === null) {
            return $this->unauthorized();
        }

        try {
            $builder = $this->branchModel
                ->select([
                    'branches.id',
                    'branches.company_id',
                    'branches.branch_code',
                    'branches.branch_name',
                    'branches.branch_type_id',
                    'branch_types.type_code AS branch_type_code',
                    'branch_types.type_name AS branch_type_name',
                    'branches.gstin',
                    'branches.email',
                    'branches.phone',
                    'branches.city',
                    'branches.district',
                    'branches.state_name',
                    'branches.state_code',
                    'branches.country_code',
                    'branches.postal_code',
                    'branches.latitude',
                    'branches.longitude',
                    'branches.is_head_office',
                    'branches.is_active',
                    'branches.created_at',
                    'branches.updated_at',
                ])
                ->join('branch_types', 'branch_types.id = branches.branch_type_id')
                ->where(
                    'branches.company_id',
                    (int) $user->company_id
                );

            if (! $this->authorization->isSuperAdmin($user)) {
                $accessibleBranchIds =
                    $this->authorization->getAccessibleBranchIds($user);

                if ($accessibleBranchIds === []) {
                    return $this->response->setJSON([
                        'success' => true,
                        'message' => 'Branches retrieved successfully.',
                        'data' => [
                            'branches' => [],
                        ],
                    ]);
                }

                $builder->whereIn('branches.id', $accessibleBranchIds);
            }

            $branches = $builder
                ->orderBy('is_head_office', 'DESC')
                ->orderBy('branch_name', 'ASC')
                ->findAll();

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Branches retrieved successfully.',
                'data' => [
                    'branches' => $branches,
                ],
            ]);
        } catch (Throwable $exception) {
            return $this->serverError(
                'Branch list retrieval failed.',
                $exception
            );
        }
    }

    /**
     * Return one accessible branch.
     */
    public function show(int $id): ResponseInterface
    {
        $user = auth('session')->user();

        if ($user === null) {
            return $this->unauthorized();
        }

        if ($id <= 0) {
            return $this->notFound();
        }

        try {
            $branch = $this->branchModel
                ->select('branches.*, branch_types.type_code AS branch_type_code, branch_types.type_name AS branch_type_name')
                ->join('branch_types', 'branch_types.id = branches.branch_type_id')
                ->where('branches.company_id', (int) $user->company_id)
                ->find($id);

            if ($branch === null) {
                return $this->notFound();
            }

            if (! $this->authorization->isSuperAdmin($user)) {
                $accessibleBranchIds =
                    $this->authorization->getAccessibleBranchIds($user);

                if (! in_array($id, $accessibleBranchIds, true)) {
                    return $this->notFound();
                }
            }

            return $this->response->setJSON([
                'success' => true,
                'message' => 'Branch retrieved successfully.',
                'data' => [
                    'branch' => $branch,
                ],
            ]);
        } catch (Throwable $exception) {
            return $this->serverError(
                'Branch retrieval failed.',
                $exception
            );
        }
    }

    private function unauthorized(): ResponseInterface
    {
        return $this->response
            ->setStatusCode(ResponseInterface::HTTP_UNAUTHORIZED)
            ->setJSON([
                'success' => false,
                'message' => 'Authentication required.',
            ]);
    }

    /**
     * Return 404 for missing or inaccessible branches so another
     * company's branch information is never exposed.
     */
    private function notFound(): ResponseInterface
    {
        return $this->response
            ->setStatusCode(ResponseInterface::HTTP_NOT_FOUND)
            ->setJSON([
                'success' => false,
                'message' => 'Branch not found.',
            ]);
    }

    private function serverError(
        string $logMessage,
        Throwable $exception
    ): ResponseInterface {
        log_message(
            'error',
            $logMessage . ' {message}',
            ['message' => $exception->getMessage()]
        );

        return $this->response
            ->setStatusCode(
                ResponseInterface::HTTP_INTERNAL_SERVER_ERROR
            )
            ->setJSON([
                'success' => false,
                'message' => 'Unable to process the branch request.',
            ]);
    }
}
